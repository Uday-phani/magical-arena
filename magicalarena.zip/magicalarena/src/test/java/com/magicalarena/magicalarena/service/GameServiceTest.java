	package com.magicalarena.magicalarena.service;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

import com.magicalarena.magicalarena.models.Player;
import com.magicalarena.magicalarena.services.GameService;

public class GameServiceTest {
	  @Test
	    void fightPlayers() {
	        GameService gameService = new GameService();
	        Player playerA = new Player("Player A", 50, 5, 10);
	        Player playerB = new Player("Player B", 100, 10, 5);

	        String result = gameService.fight(playerA, playerB);

	        assertTrue(result.contains("wins!")); // Check if the output contains a winner
	        assertTrue(playerA.getHealth() == 0 || playerB.getHealth() == 0); // Ensure one player dies
	    }

}
