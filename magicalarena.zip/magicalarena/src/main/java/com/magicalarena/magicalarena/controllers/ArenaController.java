package com.magicalarena.magicalarena.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.magicalarena.magicalarena.models.Player;
import com.magicalarena.magicalarena.services.GameService;

@RestController
	@RequestMapping("/arena")
	public class ArenaController {

	    @Autowired
	    private GameService gameService;

	    @GetMapping("/fight")
	    public String fightPlayers() {
	        Player playerA = new Player("Player A", 50, 5, 10);
	        Player playerB = new Player("Player B", 100, 10, 5);

	        return gameService.fight(playerA, playerB);
	    }


}
