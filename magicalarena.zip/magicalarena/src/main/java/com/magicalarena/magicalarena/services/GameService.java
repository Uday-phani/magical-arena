package com.magicalarena.magicalarena.services;


import org.springframework.stereotype.Service;

import com.magicalarena.magicalarena.models.Player;

@Service
public class GameService {

    public String fight(Player playerA, Player playerB) {
        StringBuilder battleLog = new StringBuilder();

        // Fight until one player dies
        while (playerA.getHealth() > 0 && playerB.getHealth() > 0) {
            Player attacker = (playerA.getHealth() <= playerB.getHealth()) ? playerA : playerB;
            Player defender = (attacker == playerA) ? playerB : playerA;

            battleLog.append(executeTurn(attacker, defender));
            battleLog.append("\n");

            if (defender.getHealth() <= 0) {
                battleLog.append(defender.getName()).append(" has died. ");
                battleLog.append(attacker.getName()).append(" wins!\n");
                break;
            }
        }

        return battleLog.toString();
    }

    private String executeTurn(Player attacker, Player defender) {
        int attackRoll = attacker.rollDice();
        int defendRoll = defender.rollDice();

        int attackDamage = attackRoll * attacker.getAttack();
        int defendValue = defendRoll * defender.getStrength();

        int netDamage = Math.max(0, attackDamage - defendValue);
        defender.setHealth(defender.getHealth() - netDamage);

        return attacker.getName() + " attacks! (Roll: " + attackRoll + ", Damage: " + attackDamage + ") "
                + defender.getName() + " defends! (Roll: " + defendRoll + ", Defended: " + defendValue + ") "
                + defender.getName() + " takes " + netDamage + " damage. (Health: " + defender.getHealth() + ")";
    }

}
