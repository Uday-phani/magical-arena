package com.magicalarena.magicalarena;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MagicalarenaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MagicalarenaApplication.class, args);
	}

}
